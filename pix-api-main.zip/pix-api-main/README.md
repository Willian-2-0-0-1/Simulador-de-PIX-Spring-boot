# API PIX

API REST para gerenciamento de transferências PIX desenvolvida com Spring Boot.

## Tecnologias Utilizadas

- Java 17
- Spring Boot 3.2.2
- Spring Security
- JWT para autenticação
- H2 Database
- Maven

## Como Executar

1. Clone o repositório
```bash
git clone [url-do-seu-repositorio]
```

2. Entre na pasta do projeto
```bash
cd pix-api
```

3. Execute o projeto
```bash
mvn spring-boot:run
```

A API estará disponível em `http://localhost:8080`

## Endpoints

### Cadastro de Usuário
```http
POST /api/pix/cadastro
Content-Type: application/json

{
    "nome": "Nome do Usuário",
    "email": "usuario@exemplo.com",
    "senha": "senha123",
    "chavePix": "chave-pix",
    "banco": "Nome do Banco",
    "saldo": 1000.00
}
```

### Login
```http
POST /api/pix/login
Content-Type: application/json

{
    "email": "usuario@exemplo.com",
    "senha": "senha123"
}
```

### Consultar Saldo
```http
GET /api/pix/saldo
Authorization: Bearer seu_token_jwt
```

### Fazer Transferência
```http
POST /api/pix/transferir
Content-Type: application/json
Authorization: Bearer seu_token_jwt

{
    "chavePix": "chave-pix-destino",
    "valor": 100.00,
    "description": "Descrição da transferência"
}
```

## Segurança

- Todas as senhas são criptografadas antes de serem armazenadas
- Endpoints protegidos com JWT
- Token expira em 24 horas
