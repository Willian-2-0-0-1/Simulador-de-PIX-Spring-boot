INSERT INTO pix_keys (nome, email, banco, chave_pix, senha, saldo, created_at) 
VALUES 
('João Silva', 'joao@email.com', 'Bradesco', '1234-5', '$2a$10$8YxZ5xZ5xZ5xZ5xZ5xZ5xOxZ5xZ5xZ5xZ5xZ5xZ5xZ5xZ5xZ5x', 200.00, CURRENT_TIMESTAMP()),
('Maria Santos', 'maria@email.com', 'Itaú', '6789-0', '$2a$10$8YxZ5xZ5xZ5xZ5xZ5xZ5xOxZ5xZ5xZ5xZ5xZ5xZ5xZ5xZ5xZ5x', 200.00, CURRENT_TIMESTAMP());
