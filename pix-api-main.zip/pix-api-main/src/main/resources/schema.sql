DROP TABLE IF EXISTS pix_transactions;
DROP TABLE IF EXISTS pix_keys;

CREATE TABLE pix_keys (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    banco VARCHAR(255) NOT NULL,
    chave_pix VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    saldo DECIMAL(10,2) NOT NULL DEFAULT 200.00,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pix_transactions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    source_key VARCHAR(255) NOT NULL,
    destination_key VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_key) REFERENCES pix_keys(chave_pix),
    FOREIGN KEY (destination_key) REFERENCES pix_keys(chave_pix)
);
