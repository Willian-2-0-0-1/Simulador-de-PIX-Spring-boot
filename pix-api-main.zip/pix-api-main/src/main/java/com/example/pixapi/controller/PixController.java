package com.example.pixapi.controller;

import com.example.pixapi.model.PixKey;
import com.example.pixapi.security.JwtTokenUtil;
import com.example.pixapi.service.PixService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/pix")
public class PixController {

    private final PixService pixService;
    private final JwtTokenUtil jwtTokenUtil;

    public PixController(PixService pixService, JwtTokenUtil jwtTokenUtil) {
        this.pixService = pixService;
        this.jwtTokenUtil = jwtTokenUtil;
    }

    @PostMapping("/cadastro")
    public ResponseEntity<PixKey> cadastrar(@RequestBody PixKey pixKey) {
        return ResponseEntity.ok(pixService.cadastrar(pixKey));
    }

    @GetMapping("/saldo")
    public ResponseEntity<BigDecimal> consultarSaldo(@RequestHeader("Authorization") String token) {
        String email = extractEmailFromToken(token);
        return ResponseEntity.ok(pixService.consultarSaldo(email));
    }

    @PostMapping("/transferir")
    public ResponseEntity<?> transferir(
            @RequestHeader("Authorization") String token,
            @RequestBody Map<String, String> request) {
        
        String emailOrigem = extractEmailFromToken(token);
        String chavePixDestino = request.get("chavePix");
        BigDecimal valor = new BigDecimal(request.get("valor"));

        pixService.transferir(emailOrigem, chavePixDestino, valor);
        return ResponseEntity.ok().build();
    }

    private String extractEmailFromToken(String token) {
        if (token != null && token.startsWith("Bearer ")) {
            String jwt = token.substring(7);
            return jwtTokenUtil.extractUsername(jwt);
        }
        throw new RuntimeException("Token inválido");
    }
}
