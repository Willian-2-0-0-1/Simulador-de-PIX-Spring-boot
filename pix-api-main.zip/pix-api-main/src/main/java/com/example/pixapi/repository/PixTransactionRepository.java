package com.example.pixapi.repository;

import com.example.pixapi.model.PixTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PixTransactionRepository extends JpaRepository<PixTransaction, Long> {
}
