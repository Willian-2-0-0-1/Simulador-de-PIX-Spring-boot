package com.example.pixapi.model;

public enum TransactionStatus {
    PENDING,
    COMPLETED,
    FAILED
}
