package com.example.pixapi.service;

import com.example.pixapi.repository.PixKeyRepository;
import com.example.pixapi.model.PixKey;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class AuthService implements UserDetailsService {

    private final PixKeyRepository pixKeyRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(PixKeyRepository pixKeyRepository, PasswordEncoder passwordEncoder) {
        this.pixKeyRepository = pixKeyRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        PixKey pixKey = pixKeyRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Email não encontrado: " + email));
        return new User(pixKey.getEmail(), pixKey.getSenha(), new ArrayList<>());
    }

    public String encodePassword(String password) {
        return passwordEncoder.encode(password);
    }
}
