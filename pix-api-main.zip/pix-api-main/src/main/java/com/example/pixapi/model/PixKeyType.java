package com.example.pixapi.model;

public enum PixKeyType {
    CPF,
    CNPJ,
    EMAIL,
    PHONE,
    RANDOM
}
