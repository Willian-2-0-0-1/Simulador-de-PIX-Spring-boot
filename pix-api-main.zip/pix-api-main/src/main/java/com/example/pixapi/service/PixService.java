package com.example.pixapi.service;

import com.example.pixapi.model.PixKey;
import com.example.pixapi.repository.PixKeyRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class PixService {

    private final PixKeyRepository pixKeyRepository;
    private final AuthService authService;

    public PixService(PixKeyRepository pixKeyRepository, AuthService authService) {
        this.pixKeyRepository = pixKeyRepository;
        this.authService = authService;
    }

    public PixKey cadastrar(PixKey pixKey) {
        Optional<PixKey> existingByEmail = pixKeyRepository.findByEmail(pixKey.getEmail());
        if (existingByEmail.isPresent()) {
            throw new RuntimeException("Email já cadastrado");
        }

        Optional<PixKey> existingByChavePix = pixKeyRepository.findByChavePix(pixKey.getChavePix());
        if (existingByChavePix.isPresent()) {
            throw new RuntimeException("Chave PIX já cadastrada");
        }

        pixKey.setSenha(authService.encodePassword(pixKey.getSenha()));
        pixKey.setSaldo(pixKey.getSaldo() != null ? pixKey.getSaldo() : BigDecimal.ZERO);
        pixKey.setCreatedAt(LocalDateTime.now());
        return pixKeyRepository.save(pixKey);
    }

    public BigDecimal consultarSaldo(String email) {
        PixKey pixKey = pixKeyRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Email não encontrado"));
        return pixKey.getSaldo();
    }

    public void transferir(String emailOrigem, String chavePixDestino, BigDecimal valor) {
        if (valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Valor deve ser maior que zero");
        }

        PixKey origem = pixKeyRepository.findByEmail(emailOrigem)
                .orElseThrow(() -> new RuntimeException("Email de origem não encontrado"));

        PixKey destino = pixKeyRepository.findByChavePix(chavePixDestino)
                .orElseThrow(() -> new RuntimeException("Chave PIX de destino não encontrada"));

        if (origem.getSaldo().compareTo(valor) < 0) {
            throw new RuntimeException("Saldo insuficiente");
        }

        origem.setSaldo(origem.getSaldo().subtract(valor));
        destino.setSaldo(destino.getSaldo().add(valor));

        pixKeyRepository.save(origem);
        pixKeyRepository.save(destino);
    }
}
