package com.example.pixapi.repository;

import com.example.pixapi.model.PixKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PixKeyRepository extends JpaRepository<PixKey, Long> {
    Optional<PixKey> findByEmail(String email);
    Optional<PixKey> findByChavePix(String chavePix);
}
